<div id="SomeSlider">
<input checked type=radio name=respond id=desktop />
<input type=radio name=respond id=tablet />
<input type=radio name=respond id=mobile />
<article id=slider>

    <input checked type=radio name=slider id=slide1 />
    <input type=radio name=slider id=slide2 />
    <input type=radio name=slider id=slide3 />
    <input type=radio name=slider id=slide4 />
    <input type=radio name=slider id=slide5 />

    <div id=slides>

        <div id=overflow>

            <div class=inner>

                <article>
                    <div class=info><h3>Cloud Dragon</h3> by <a href="http://voyager3.tumblr.com">Brendan Zabarauskas</a></div>
                    <img src="slider/images/CouldDragonByBjzaba.png" />
                </article>


                <article>
                    <div class=info><h3>Mountain Fort</h3> by <a href="http://voyager3.tumblr.com">Brendan Zabarauskas</a></div>
                    <img src="slider/images/MountainFortByBjzaba.png" />
                </article>

                <article>
                    <div class=info><h3>Mountain Outpost</h3> by <a href="http://voyager3.tumblr.com">Brendan Zabarauskas</a></div>

                    <img src="slider/images/MountainOutpostByBjzaba.png" />
                </article>

                <article>
                    <div class=info><h3>Cliffs</h3> by <a href="http://voyager3.tumblr.com">Brendan Zabarauskas</a></div>
                    <img src="slider/images/CliffsByBjzaba.png" />
                </article>

                <article>

                    <div class=info><h3>Hill Fort</h3> by <a href="http://voyager3.tumblr.com">Brendan Zabarauskas</a></div>
                    <img src="slider/images/HillFortByBjzaba.png" />
                </article>

            </div>

        </div>

    </div>


    <div id=controls>

        <label for=slide1></label>
        <label for=slide2></label>
        <label for=slide3></label>
        <label for=slide4></label>
        <label for=slide5></label>

    </div>


    <div id=active>

        <label for=slide1></label>
        <label for=slide2></label>
        <label for=slide3></label>
        <label for=slide4></label>
        <label for=slide5></label>

    </div>
</article>
</div>

<div id="Photographer">

    <div id="PhotographerIMG">
        <div style="float: left; width: 40%; margin-left: 20px;">
            <img src="FotographerFoto.jpg" width="300px" height="300px">
        </div>
        <div style="float: left; width: 50%;">
            <div id="Welcome"> Рад приветствовать Вас на моем сайте!</div>
            <div id ="otherWelcome">
                Я - Еремей Семенов, свободный фотограф.<br><br>
                Моя фотокамера: Canon 6d, объективы 50мм 1.4, 85 1.8, 24-70 2.8<br>
                Работаю в Питербурге и Москве.<br>
                Длительность полной фотосесси 2 часа.
            </div>
        </div>
    </div>
    <div id="BigInfo">
        <hr>
        Я Еремей Семенов профессиональный фотограф в Санкт-Петербурге со значительным опытом работы и большой любовью к тому, что  делаю! Специализируюсь на различных жанрах фотографии, таких как: - свадебная фотография, - семейная и детская съемки, - love-story, - фэнтезийная. Понимание и знание специфики студийной и уличной съемок! Гибкий подход к клиентам - фотосъемка под Вашу задачу и задумку. Наличие наработанной базы визажистов-стилистов. Наличие художественного вкуса, видение выгодных ракурсов, работа на результат!  ­­
    </div>
</div>


<div>




</div>